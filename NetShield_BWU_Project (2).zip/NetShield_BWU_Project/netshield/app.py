import csv
import ipaddress
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from datetime import datetime
from scanner import validate_target, discover_hosts, scan_ports

class NetShieldApp:
    def __init__(self, root):
        self.root = root
        root.title("NetShield | Network Scanner")
        root.geometry("900x620")
        root.configure(bg="#111827")
        self.results = []
        self.hosts = []

        title = tk.Label(root, text="NETSHIELD", font=("Segoe UI", 24, "bold"),
                         bg="#111827", fg="#00DFA5")
        title.pack(pady=(16, 2))
        tk.Label(root, text="Network Scanning & Security Assessment Tool",
                 bg="#111827", fg="#D1D5DB", font=("Segoe UI", 11)).pack()

        panel = tk.Frame(root, bg="#1F2937", padx=14, pady=14)
        panel.pack(fill="x", padx=18, pady=18)
        tk.Label(panel, text="Private IP / network (e.g. 127.0.0.1 or 192.168.1.0/24)",
                 bg="#1F2937", fg="white").pack(anchor="w")
        self.target = tk.Entry(panel, font=("Segoe UI", 12), width=44)
        self.target.pack(anchor="w", pady=8)
        self.target.insert(0, "127.0.0.1")

        buttons = tk.Frame(panel, bg="#1F2937")
        buttons.pack(anchor="w")
        self.scan_btn = tk.Button(buttons, text="Discover & Scan", command=self.start,
                                  bg="#00DFA5", fg="#111827", font=("Segoe UI", 10, "bold"))
        self.scan_btn.pack(side="left", padx=(0, 8))
        tk.Button(buttons, text="Export CSV", command=self.export,
                  bg="#374151", fg="white").pack(side="left")

        self.status = tk.Label(root, text="Ready. Scan only networks you are authorized to assess.",
                              bg="#111827", fg="#00DFA5")
        self.status.pack(pady=6)

        cols = ("IP", "Port", "Service", "Status", "Observation")
        self.table = ttk.Treeview(root, columns=cols, show="headings", height=20)
        widths = (180, 80, 180, 160, 250)
        for c, w in zip(cols, widths):
            self.table.heading(c, text=c)
            self.table.column(c, width=w)
        self.table.pack(fill="both", expand=True, padx=18, pady=(8, 18))

    def start(self):
        target = self.target.get().strip()
        try:
            validated = validate_target(target)
        except Exception as e:
            messagebox.showerror("Invalid target", str(e))
            return
        self.scan_btn.config(state="disabled")
        self.table.delete(*self.table.get_children())
        self.results = []
        self.status.config(text="Discovering reachable hosts...")
        threading.Thread(target=self.worker, args=(validated,), daemon=True).start()

    def worker(self, target):
        try:
            self.hosts = discover_hosts(target)
            all_rows = []
            for host in self.hosts:
                rows = scan_ports(host)
                for row in rows:
                    if row["status"] == "OPEN":
                        row["observation"] = self.observation(row["port"])
                        all_rows.append(row)
            self.root.after(0, self.display, all_rows, None)
        except Exception as e:
            self.root.after(0, self.display, [], str(e))

    @staticmethod
    def observation(port):
        notes = {
            21: "FTP may transmit data without encryption; review configuration.",
            23: "Telnet is unencrypted; consider disabling it.",
            445: "SMB should be limited to trusted networks.",
            3389: "Remote Desktop should be access-controlled.",
            3306: "Database service; avoid exposing it unnecessarily.",
            6379: "Redis service; review authentication and network access.",
            9200: "Search service; review access controls."
        }
        return notes.get(port, "Review whether this service needs to be accessible.")

    def display(self, rows, error):
        self.scan_btn.config(state="normal")
        if error:
            self.status.config(text="Scan error")
            messagebox.showerror("Scan error", error)
            return
        self.results = rows
        for r in rows:
            self.table.insert("", "end", values=(r["ip"], r["port"], r["service"],
                                                 r["status"], r.get("observation", "")))
        self.status.config(text=f"Completed: {len(self.hosts)} reachable host(s), "
                               f"{len(rows)} open port result(s).")

    def export(self):
        if not self.results:
            messagebox.showinfo("No results", "Run a scan first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv",
                                           filetypes=[("CSV files", "*.csv")],
                                           initialfile="netshield_report.csv")
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["ip", "port", "service", "status", "observation"])
            writer.writeheader()
            writer.writerows(self.results)
        messagebox.showinfo("Exported", "CSV report saved successfully.")

if __name__ == "__main__":
    root = tk.Tk()
    NetShieldApp(root)
    root.mainloop()
