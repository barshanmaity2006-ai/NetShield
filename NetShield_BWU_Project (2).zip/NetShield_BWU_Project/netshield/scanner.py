import ipaddress
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed

PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 135: "RPC", 139: "NetBIOS",
    443: "HTTPS", 445: "SMB", 3306: "MySQL", 3389: "RDP",
    5432: "PostgreSQL", 5900: "VNC", 6379: "Redis",
    8080: "HTTP Alternate", 8443: "HTTPS Alternate",
    9200: "Elasticsearch", 27017: "MongoDB"
}
DISCOVERY_PORTS = (22, 80, 443, 445, 3389)

def validate_target(target):
    """Accept one IPv4 address or a private IPv4 network no larger than /24."""
    target = target.strip()
    if "/" in target:
        network = ipaddress.ip_network(target, strict=False)
        if network.version != 4 or not network.is_private:
            raise ValueError("Use a private IPv4 network only.")
        if network.prefixlen < 24:
            raise ValueError("For safety and speed, networks larger than /24 are not accepted.")
        return network
    ip = ipaddress.ip_address(target)
    if ip.version != 4:
        raise ValueError("Only IPv4 targets are supported.")
    if not (ip.is_private or ip.is_loopback):
        raise ValueError("Use a private IPv4 address or localhost only.")
    return ip

def is_port_open(ip, port, timeout=0.35):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            return sock.connect_ex((str(ip), port)) == 0
    except OSError:
        return False

def discover_hosts(network, callback=None):
    if isinstance(network, ipaddress.IPv4Address):
        hosts = [network]
    else:
        hosts = list(network.hosts())
    found = []
    def probe(ip):
        for p in DISCOVERY_PORTS:
            if is_port_open(ip, p):
                return str(ip)
        return None
    with ThreadPoolExecutor(max_workers=32) as pool:
        futures = {pool.submit(probe, ip): ip for ip in hosts}
        for fut in as_completed(futures):
            result = fut.result()
            if result:
                found.append(result)
            if callback:
                callback(len(futures), len(found))
    return sorted(found, key=lambda x: int(ipaddress.ip_address(x)))

def scan_ports(ip, ports=None):
    ports = ports or list(PORTS.keys())
    rows = []
    for port in ports:
        open_state = is_port_open(ip, port)
        rows.append({
            "ip": str(ip), "port": port, "service": PORTS.get(port, "Unknown"),
            "status": "OPEN" if open_state else "CLOSED/UNRESPONSIVE"
        })
    return rows
