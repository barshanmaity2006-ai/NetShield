# NetShield – BWU Project Report Outline

This report outline follows the supplied Table of Contents. Complete the chapters with screenshots and measured results from your own test environment; do not claim experiments or results that were not performed.

## Preliminary pages
- Bonafide Certificate
- Declaration by the Student
- Acknowledgment
- Abstract
- Table of Contents
- List of Figures
- List of Tables

## 1. Introduction
### 1.1 Introduction
Explain computer networks, ports, and why basic visibility matters.
### 1.2 Background
Explain IP addresses, TCP, and network services in beginner-friendly language.
### 1.3 Problem Statement
Small users and learners may lack an easy way to view reachable devices and exposed common TCP services.
### 1.4 Objectives
Host discovery, common-port checking, readable results, observations, and CSV export.
### 1.5 Scope of the Project
Private IPv4 targets, limited subnet scope, TCP-connect scanning, and educational use.
### 1.6 Organisation of the Report
Brief chapter-by-chapter summary.

## 2. Literature Review
### 2.1 Existing Research
Discuss network scanning and basic network inventory concepts using verified sources.
### 2.2 Review of Related Works
Review established tools such as Nmap and other network inventory tools; cite sources.
### 2.3 Comparative Analysis
Compare NetShield's educational scope with established tools using a factual feature table.
### 2.4 Research Gap
Describe the learning-oriented interface and simple explanations as the project's educational focus.

## 3. System Analysis and Requirements
### 3.1 Existing System
Describe manual checks and the complexity of professional tools for beginners.
### 3.2 Proposed System
Describe the NetShield workflow and features.
### 3.3 Functional Requirements
Target validation, host discovery, port scanning, display, export.
### 3.4 Non-functional Requirements
Usability, clarity, responsiveness, bounded scanning, and basic reliability.
### 3.5 Hardware and Software Requirements
PC/laptop, Python, VS Code, Windows/Linux, Tkinter.

## 4. System Design and Methodology
### 4.1 System Architecture
GUI, validation, scanner, result display, export.
### 4.2 Proposed Methodology
Validate target; discover hosts; scan common ports; summarize; export.
### 4.3 Flowchart
Create a flowchart based on the implemented workflow.
### 4.4 UML Diagrams
Use case, activity, and sequence diagrams.
### 4.5 Database Design
Version 1 has no database; explain CSV export. Database can be added in a later version.
### 4.6 Algorithm Design
Describe validation, host discovery, TCP connection test, and reporting.

## 5. Implementation
### 5.1 Development Environment
Document actual OS, Python version, and editor used.
### 5.2 Tools and Technologies
Python, socket, Tkinter, threading, CSV.
### 5.3 Module-wise Implementation
Explain scanner and GUI modules.
### 5.4 Important Code Implementation
Explain key functions in plain language.

## 6. Result and Discussion
### 6.1 Experimental Setup
Describe only the lab devices/network you actually used.
### 6.2 Output Screenshots
Insert your own screenshots.
### 6.3 Performance Evaluation
Measure actual run time and results on your test setup.
### 6.4 Result Analysis
Discuss what was found and limitations.
### 6.5 Discussion
Explain usefulness and limitations.

## 7. Testing and Validation
### 7.1 Testing Methodology
Describe controlled tests on permitted devices.
### 7.2 Unit Testing
Test target validation and port checking.
### 7.3 Integration Testing
Test GUI-to-scanner and scanner-to-export workflow.
### 7.4 System Testing
Test the full application.
### 7.5 Test Cases and Results
Record actual pass/fail results and observations.

## 8. Conclusion and Future Scope
Summarize what was implemented. Future scope: scan history database, richer reports, optional Nmap integration, improved device discovery, and dashboard.

## 9. References
Add the sources actually consulted, with consistent citation formatting.
