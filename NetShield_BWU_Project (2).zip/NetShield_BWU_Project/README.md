# NetShield – BWU Project

A beginner-friendly Python desktop network scanning tool for authorized private-network assessments.

## Features
- Accepts a private IPv4 address or a private subnet up to /24.
- Discovers reachable hosts by checking a small set of common ports.
- Scans 20 common TCP ports on discovered hosts.
- Displays open ports and simple observations.
- Exports results as CSV.

## Requirements
- Python 3.10 or newer
- Tkinter (normally included with standard Python installations)

## Run
From this folder:
```bash
cd netshield
python app.py
```
On Windows, you may use:
```bash
py app.py
```

## Safety scope
Use only on networks and devices you own or are authorized to assess. The tool accepts private IPv4 targets and loopback addresses only, and restricts subnet scans to /24 or smaller.

## Limitations
- TCP connect scanning only.
- Host discovery relies on a few common TCP ports and may miss devices with all discovery ports closed.
- It does not identify operating systems or verify vulnerabilities.
- A closed/unresponsive result can also reflect filtering or timeout, so it is not a definitive classification.
